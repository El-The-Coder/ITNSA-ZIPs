CREATE TABLE `competitors` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(255) NOT NULL,
    PRIMARY_KEY(`id`)
);

INSERT INTO `competitors` (name) VALUES ('adam');

